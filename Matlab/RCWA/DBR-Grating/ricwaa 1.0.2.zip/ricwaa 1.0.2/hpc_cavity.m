% hcgcavity
wavelength=800;
% the wavelength of the light in the air
dbrwavelength=800;
% the wavelength used for DBR setting
incidentangle=0;
% the angle between the incident light and the normal direction of the
% layers, in degree
period=585;
% the grating period
dutycycle=0.35;
gratingthickness=125;
airgap=400;
numtopdbr=4;
numbotdbr=50;
nmode=40;
nAlAs=2.9; 
% low index DBR layer, cavity
nGaAs=3.42;
cAlAs=0.2;
cGaAs=0.8;                              
% substrate
nAlGaAs=(cGaAs*nGaAs+cAlAs*nAlAs);           
% HCG, High index DBR layer
gratingindex=nAlGaAs;
dbrhighindex=nAlGaAs;
dbrlowindex=nAlAs;
cavityindex=nAlAs;
substrateindex=nGaAs;
dbrhighthickness=dbrwavelength/dbrhighindex/4;   
% DBR
dbrlowthickness=dbrwavelength/dbrlowindex/4;
cavitythickness=dbrwavelength/cavityindex/2;
% cavity
L=6+2*(numtopdbr+numbotdbr);

rcwa=RCWA('period',period,'modenumber',nmode);
rcwa.ApplyLightSource('poL','Te','wV',wavelength,'angle',incidentangle);
%rcwa.LightSource.SetPolarization('TM');
%rcwa.LightSource.SetWavelength(wavelength);
%rcwa.LightSource.SetIncidentAngle(incidentangle);
rcwa.SetLayer(1,'index',1,'nAme','In');
rcwa.SetLayer(2,'index',substrateindex,'name','oUT');
rcwa.AddLayer('lYt',gratingthickness,...
    'profile',[-rcwa.Period/2*dutycycle,...
    rcwa.Period/2*dutycycle...
    ,gratingindex],'name','hcg-grating');
rcwa.AddLayer('lyt',airgap,'name','airgap');
rcwa.AddLayer('lyt',dbrhighthickness,'index',dbrhighindex);
for icount=5:2:4+2*numtopdbr
    rcwa.AddLayer('lyt',dbrlowthickness,'index',dbrlowindex);
    rcwa.AddLayer('lyt',dbrhighthickness,'index',dbrhighindex);
end
rcwa.AddLayer('lyt',cavitythickness,'index',cavityindex);
for icount=6+2*numtopdbr:2:L-1
    rcwa.AddLayer('lyt',dbrhighthickness,'index',dbrhighindex);
    rcwa.AddLayer('lyt',dbrlowthickness,'index',dbrlowindex);
end

rcwa.Run;

rcwa.AddFieldDetector;
rcwa.SetFieldDetector(1,'x',linspace(-rcwa.Period,rcwa.Period,100),...
    'z',linspace(-rcwa.ComputingResults.StackThickness/4,...
    rcwa.ComputingResults.StackThickness*5/4,800),'modal','scatter');
rcwa.AddFieldDetector('x',0,'z',linspace(...
    -rcwa.ComputingResults.StackThickness/4,...
    rcwa.ComputingResults.StackThickness*5/4,800));


rcwa.FieldComputing;

subplot(2,1,1);rcwa.FieldPlot(1);
subplot(2,1,2);rcwa.StructureIndexMap;