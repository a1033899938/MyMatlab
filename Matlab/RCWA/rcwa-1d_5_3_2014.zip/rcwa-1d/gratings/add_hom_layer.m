% add_hom_layer(layer_number,Lambda,layer_thickness,ref_index)

function data_layer=add_hom_layer(Lambda,layer_thickness,ref_index)

data_layer=[layer_thickness, 0, ref_index, Lambda];


