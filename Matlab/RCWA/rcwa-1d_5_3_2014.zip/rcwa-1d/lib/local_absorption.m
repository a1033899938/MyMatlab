% Author: Pavel Kwiecien, pavel.kwiecien@seznam.cz
% Czech Technical University in Prage, Optical Physics Group, Czech Republic

epsilon_matrix_local=[];
epsilon_matrix_local_=[];

plot_field_region_1=2;
plot_field_region_2=1;
plot_field_region_3=2;

if polarization==0
    for i=4:1:6
        conical_field_component=i;
        if i==4
            try
                field2_6_local_ab;
                old_field_version=2;
            catch
                sprintf('switch to older version');
                old_field_version=1;
                field2_5_local_ab;
            end                
            component_E_x=field_E_2;                
            clear field_E_2
        elseif i==5
            try
                field2_6_local_ab;
                old_field_version=2;
            catch
                sprintf('switch to older version');
                old_field_version=1;
                field2_5_local_ab;
            end                
            component_E_y=field_E_2;                
            clear field_E_2
        elseif i==6    
            if old_field_version==1
                field2_5_local_ab;
            else
                field2_6_local_ab;
            end
            component_E_z=field_E_2;    
            clear field_E_2
        end
    end
elseif polarization==1                    
    for i=1:2:3
        planar_field_component=i;
        if i==1
            try
                field2_6_local_ab;
                old_field_version=2;
            catch
                sprintf('switch to older version');
                old_field_version=1;
                field2_5_local_ab;
            end                
            component_E_x=field_E_2;                
            clear field_E_2
        elseif i==3    
            if old_field_version==1
                field2_5_local_ab;
            else
                field2_6_local_ab;
            end
            component_E_z=field_E_2;    
            clear field_E_2
        end
    end
elseif polarization==2
    for i=2:1:2
        planar_field_component=i;
        try
            field2_6_local_ab;
            old_field_version=2;
        catch
            sprintf('switch to older version');
            old_field_version=1;
            field2_5_local_ab;
        end
        component_E_y=field_E_2;
        clear field_E_2              
    end
end

%-----------------------------------------------------------
%normovani=sqrt(mu/epsilon);
if polarization==0
    intensity_E=(abs(component_E_x)).^2+(abs(component_E_y)).^2+(abs(component_E_z)).^2;
elseif polarization==1 
    intensity_E=((abs(component_E_x)).^2+(abs(component_E_z)).^2);
elseif polarization==2
    intensity_E=(abs(component_E_y)).^2;
end

% minus sign because imag(eps)<0
local_absoption_matrix=-(k_0^2/k_1_z((number_of_orders+1)/2)*z_res_/resolution_x).*bsxfun(@times,intensity_E,imag(epsilon_matrix_local/epsilon));

global_absorption=1-sum(D_R)-sum(D_T);

if polarization==1
    local_absoption_matrix=local_absoption_matrix/(sqrt(mu/epsilon)/n1)^2;
elseif polarization==2
    % ok
end

z_min=1;
z_max=absorption_in_layer_thickness(1);
layer_absorption=zeros(number_of_layers,1);
for i=1:1:number_of_layers
    layer_absorption(i)=sum(sum(local_absoption_matrix(:,z_min:z_max)));
    if i<number_of_layers
    z_min=z_min+absorption_in_layer_thickness(i);
    z_max=z_max+absorption_in_layer_thickness(i+1);
    end
end


integrated_absoption=sum(sum(local_absoption_matrix));
norm_constant=global_absorption/integrated_absoption;

integrated_absoption
global_absorption


%delta_x=Lambda/resolution_x;
%X=0:delta_x:Lambda;
%Y=real(S_z(:,25));
%Z=trapz(X,Y);

%cast_X=0:delta_x:1.4+delta_x;
%cast_Y=real(S_z(1:2988,25));
%cast_Z=trapz(cast_X,cast_Y);

%flux=cast_Z/Z;

size_field=size(intensity_E);
size_x=size_field(1);
size_z=size_field(2);
new_z=0:thickness/size_z:thickness-thickness/size_z;

figure;
set(gcf, 'Renderer', 'zbuffer');
surf(new_z.*1E6,x.*1E6,local_absoption_matrix); 
axis([0 thickness*1E6 x_min*1E6 x_max*1E6]);
title('local absoption');
xlabel('z [\mu{}m]','FontSize',14);
ylabel('x [\mu{}m]','FontSize',14);
shading flat;

if in_octave==1 && old_field_version==1
    view_octave([90 90]);
else
    view([90 90]);    
end



if in_octave==1 && old_field_version==1
    view_octave([90 90]);
else
    view([90 90]);    
end