% Author: Pavel Kwiecien, pavel.kwiecien@seznam.cz
% Czech Technical University in Prage, Optical Physics Group, Czech Republic

%k_x_mn=zeros(1,n_sq);
%k_y_mn=zeros(1,n_sq);
phi_i=zeros(1,n_sq);

k_1_z=zeros(n_sq,n_sq);
k_3_z=zeros(n_sq,n_sq);