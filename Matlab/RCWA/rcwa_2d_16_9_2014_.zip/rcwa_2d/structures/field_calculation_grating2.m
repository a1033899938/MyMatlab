number_of_layers=1;

l=1; % layer 1
thickness(l)=1;

coordinate_x_1=1.2.*[0,0.25,0.75,1];
coordinate_y_1=1.2.*[0,0.25,0.75,1];

r_index_1=[1, 1, 1;
    1, 1.5001, 1;
    1, 1, 1;];

%{
l=2; % layer 1
thickness(l)=1;

%coordinate_x_1=1.2.*[0,0.25,0.75,1];
%coordinate_y_1=1.2.*[0,0.25,0.75,1];

coordinate_x_2=1.2.*[0,0.25,0.75,1];
coordinate_y_2=1.2.*[0,0.25,0.75,1];

r_index_2=[1, 1, 1;
    1, 1.5, 1;
    1, 1, 1;];
%}



