#!/bin/bash
mex asr_fourier_2D_mex.c
mex asr_fourier_2D_split_bt_mex.c
mex asr_fourier_2D_split_tb_mex.c
mex alpha_beta_mex.c
mex function_sum_results.c
mex fm_conversion.c